-- סכימת-על להרחבה (תואם Postgres). חלק מהטבלאות קיימות כבר ב-ORM
-- משתמשים, תפקידים והרשאות
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  full_name TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  is_admin BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS roles (
  id SERIAL PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS user_roles (
  user_id INT REFERENCES users(id) ON DELETE CASCADE,
  role_id INT REFERENCES roles(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, role_id)
);

-- לקוחות וספקים
CREATE TABLE IF NOT EXISTS customers (
  id SERIAL PRIMARY KEY,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  billing_address TEXT,
  shipping_address TEXT,
  tax_id TEXT,
  is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS suppliers (
  id SERIAL PRIMARY KEY,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  address TEXT,
  is_active BOOLEAN DEFAULT TRUE
);

-- קטגוריות ומוצרים (יש חפיפה למודלים)
CREATE TABLE IF NOT EXISTS categories (
  id SERIAL PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  description TEXT
);

CREATE TABLE IF NOT EXISTS products (
  id SERIAL PRIMARY KEY,
  sku TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  category_id INT REFERENCES categories(id),
  unit_of_measure TEXT DEFAULT 'pcs',
  is_active BOOLEAN DEFAULT TRUE,
  standard_cost NUMERIC(12,2),
  sell_price NUMERIC(12,2),
  created_at TIMESTAMP DEFAULT NOW()
);

-- מחסנים ומלאי
CREATE TABLE IF NOT EXISTS warehouses (
  id SERIAL PRIMARY KEY,
  code TEXT UNIQUE,
  name TEXT NOT NULL,
  is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS inventory_items (
  id SERIAL PRIMARY KEY,
  product_id INT REFERENCES products(id),
  warehouse_id INT REFERENCES warehouses(id),
  qty_on_hand NUMERIC(14,3) DEFAULT 0
);

CREATE TABLE IF NOT EXISTS inventory_moves (
  id SERIAL PRIMARY KEY,
  product_id INT REFERENCES products(id),
  from_wh INT REFERENCES warehouses(id),
  to_wh INT REFERENCES warehouses(id),
  qty NUMERIC(14,3) NOT NULL,
  reason TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- רכש (PO) וקבלה
CREATE TABLE IF NOT EXISTS purchase_orders (
  id SERIAL PRIMARY KEY,
  po_number TEXT UNIQUE NOT NULL,
  supplier_id INT REFERENCES suppliers(id),
  status TEXT DEFAULT 'draft', -- draft/approved/received/closed
  currency TEXT DEFAULT 'ILS',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS purchase_order_lines (
  id SERIAL PRIMARY KEY,
  po_id INT REFERENCES purchase_orders(id) ON DELETE CASCADE,
  product_id INT REFERENCES products(id),
  qty NUMERIC(14,3) NOT NULL,
  price NUMERIC(12,2) NOT NULL,
  expected_date DATE
);

CREATE TABLE IF NOT EXISTS grn_headers ( -- Goods Receipt Note
  id SERIAL PRIMARY KEY,
  grn_number TEXT UNIQUE NOT NULL,
  po_id INT REFERENCES purchase_orders(id),
  warehouse_id INT REFERENCES warehouses(id),
  received_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS grn_lines (
  id SERIAL PRIMARY KEY,
  grn_id INT REFERENCES grn_headers(id) ON DELETE CASCADE,
  product_id INT REFERENCES products(id),
  qty NUMERIC(14,3) NOT NULL,
  lot TEXT,
  expiry DATE
);

-- הזמנות לקוח (SO) ומשלוחים
CREATE TABLE IF NOT EXISTS sales_orders (
  id SERIAL PRIMARY KEY,
  so_number TEXT UNIQUE NOT NULL,
  customer_id INT REFERENCES customers(id),
  status TEXT DEFAULT 'draft', -- draft/confirmed/shipped/invoiced/closed
  currency TEXT DEFAULT 'ILS',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sales_order_lines (
  id SERIAL PRIMARY KEY,
  so_id INT REFERENCES sales_orders(id) ON DELETE CASCADE,
  product_id INT REFERENCES products(id),
  qty NUMERIC(14,3) NOT NULL,
  price NUMERIC(12,2) NOT NULL,
  promised_date DATE
);

CREATE TABLE IF NOT EXISTS shipments (
  id SERIAL PRIMARY KEY,
  so_id INT REFERENCES sales_orders(id),
  warehouse_id INT REFERENCES warehouses(id),
  shipped_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS shipment_lines (
  id SERIAL PRIMARY KEY,
  shipment_id INT REFERENCES shipments(id) ON DELETE CASCADE,
  product_id INT REFERENCES products(id),
  qty NUMERIC(14,3) NOT NULL,
  lot TEXT
);

-- עצי מוצר (BOM) וייצור (WO)
CREATE TABLE IF NOT EXISTS boms (
  id SERIAL PRIMARY KEY,
  product_id INT REFERENCES products(id),
  version TEXT DEFAULT '1.0',
  is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS bom_items (
  id SERIAL PRIMARY KEY,
  bom_id INT REFERENCES boms(id) ON DELETE CASCADE,
  component_id INT REFERENCES products(id),
  qty_per NUMERIC(14,6) NOT NULL
);

CREATE TABLE IF NOT EXISTS work_orders (
  id SERIAL PRIMARY KEY,
  wo_number TEXT UNIQUE NOT NULL,
  product_id INT REFERENCES products(id),
  qty_planned NUMERIC(14,3) NOT NULL,
  status TEXT DEFAULT 'planned', -- planned/released/in_progress/qa_hold/complete/closed
  due_date DATE,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS wo_operations (
  id SERIAL PRIMARY KEY,
  wo_id INT REFERENCES work_orders(id) ON DELETE CASCADE,
  op_seq INT NOT NULL,
  op_name TEXT NOT NULL,
  work_center TEXT,
  std_time_minutes NUMERIC(10,2)
);

CREATE TABLE IF NOT EXISTS wo_consumptions (
  id SERIAL PRIMARY KEY,
  wo_id INT REFERENCES work_orders(id) ON DELETE CASCADE,
  component_id INT REFERENCES products(id),
  qty NUMERIC(14,3) NOT NULL
);

CREATE TABLE IF NOT EXISTS wo_productions (
  id SERIAL PRIMARY KEY,
  wo_id INT REFERENCES work_orders(id) ON DELETE CASCADE,
  product_id INT REFERENCES products(id),
  qty NUMERIC(14,3) NOT NULL,
  lot TEXT
);

-- בקרת איכות
CREATE TABLE IF NOT EXISTS qc_plans (
  id SERIAL PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  description TEXT
);

CREATE TABLE IF NOT EXISTS qc_checks (
  id SERIAL PRIMARY KEY,
  plan_id INT REFERENCES qc_plans(id),
  check_point TEXT NOT NULL,
  spec_min NUMERIC(14,3),
  spec_max NUMERIC(14,3)
);

CREATE TABLE IF NOT EXISTS qc_results (
  id SERIAL PRIMARY KEY,
  wo_id INT REFERENCES work_orders(id),
  check_id INT REFERENCES qc_checks(id),
  measured_value NUMERIC(14,3),
  result TEXT -- pass/fail
);

-- תמחיר
CREATE TABLE IF NOT EXISTS cost_ledger (
  id SERIAL PRIMARY KEY,
  doc_type TEXT, -- PO/SO/WO/etc
  doc_id INT,
  product_id INT REFERENCES products(id),
  cost_component TEXT, -- material/labor/overhead
  amount NUMERIC(14,2),
  created_at TIMESTAMP DEFAULT NOW()
);

-- מסמכים והנה״ח (מסמכים מסחריים בסיסיים – חשבונית/תע״ש/קבלה יתווספו ביישום הנהלת חשבונות)

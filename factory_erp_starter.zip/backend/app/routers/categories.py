from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from .. import models, schemas

router = APIRouter(prefix="/categories", tags=["Categories"])

@router.get("/", response_model=list[schemas.CategoryOut])
def list_categories(db: Session = Depends(get_db)):
    return db.query(models.Category).all()

@router.post("/", response_model=schemas.CategoryOut, status_code=201)
def create_category(payload: schemas.CategoryIn, db: Session = Depends(get_db)):
    if db.query(models.Category).filter_by(name=payload.name).first():
        raise HTTPException(status_code=400, detail="קטגוריה קיימת")
    obj = models.Category(**payload.dict())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj

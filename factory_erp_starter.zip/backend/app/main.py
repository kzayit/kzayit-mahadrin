from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from .db import engine, Base, get_db
from . import models
from .routers import products, categories

app = FastAPI(title="Factory ERP API", version="0.1.0", description="Starter למערכת ERP/MES")

# יצירת טבלאות ראשוניות בהרצה
Base.metadata.create_all(bind=engine)

# רישום ראוטרים
app.include_router(categories.router)
app.include_router(products.router)

@app.get("/health")
def health():
    return {"status": "ok"}

# Seed קטן לדוגמה
@app.on_event("startup")
def seed():
    db: Session = next(get_db())
    if not db.query(models.Category).first():
        c = models.Category(name="General", description="קטגוריה כללית")
        db.add(c); db.commit(); db.refresh(c)
    if not db.query(models.Product).first():
        p = models.Product(sku="DEMO-1", name="מוצר הדגמה", category_id=db.query(models.Category).first().id)
        db.add(p); db.commit()

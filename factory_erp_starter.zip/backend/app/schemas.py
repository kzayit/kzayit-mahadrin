from pydantic import BaseModel, ConfigDict
from datetime import datetime

class CategoryIn(BaseModel):
    name: str
    description: str | None = None

class CategoryOut(CategoryIn):
    id: int
    model_config = ConfigDict(from_attributes=True)

class ProductIn(BaseModel):
    sku: str
    name: str
    category_id: int | None = None
    unit_of_measure: str = "pcs"
    standard_cost: float | None = None
    sell_price: float | None = None

class ProductOut(ProductIn):
    id: int
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)

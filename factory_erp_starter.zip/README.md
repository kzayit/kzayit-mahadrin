# מערכת ERP/MES למפעל – Starter

ברוך הבא! זהו סקלטון התחלתי, מוכן לריצה מקומית, שעליו אפשר להרחיב עד מערכת מלאה (רכש, הזמנות, מלאי, מחסנים, עצי מוצר, תמחיר, ייצור, בקרת איכות, דוחות ועוד).

## טכנולוגיות
- Backend: FastAPI + SQLAlchemy (Python)
- DB: PostgreSQL
- Auth: JWT (סקלטון/מקום מוכן – להשלמה בהמשך)
- תורים/אוטומציות: Celery + Redis (להוספה בהמשך; כרגע לא כלול בקומפוז)
- Frontend: ניתן להוסיף React בהמשך (לא כלול בסקלטון הזה)
- i18n: מוכן להרחבה; שמות שדות/טבלאות באנגלית, UI יכול להיות בעברית

## איך מריצים (פשוט)
1. התקן Docker ו-Docker Compose.
2. העתק את הקובץ `.env.sample` ל-`.env` ועדכן סיסמאות אם תרצה.
3. הרץ:
   ```bash
   docker compose up --build
   ```
4. ה-API יעלה בד״כ על `http://localhost:8000`. תיעוד אינטראקטיבי: `http://localhost:8000/docs`

> הערה: בהעלאה ראשונה המערכת תיצור טבלאות בסיס ותזין קטגוריה/מוצר לדוגמה.

## מבנה
- `backend/app/main.py` – נקודת הכניסה ל-FastAPI
- `backend/app/models.py` – ORM Models (SQLAlchemy)
- `backend/app/schemas.py` – סכימות Pydantic ל-IO
- `backend/app/db.py` – חיבור למסד הנתונים
- `backend/app/routers/` – ראוטרים מודולריים (Products, Categories ועוד)
- `schema.sql` – סכימת-על רחבה יותר (PO/SO/BOM/Work Orders/QA וכו') להמשך פיתוח
- `docker-compose.yml` – קומפוז בסיסי ל-API + Postgres
- `.env.sample` – משתני סביבה לדוגמה

## צעדים הבאים (מוצעים)
- הוספת מודולי: רכש (PO), הזמנות לקוח (SO), מחסנים ותנועות מלאי, עצי מוצר (BOM), פקודות עבודה (WO), בקרת איכות (QC), תמחיר, דוחות.
- הוספת שכבת הרשאות (RBAC) ומדיניות אבטחה (JWT/Keycloak/OPA).
- הוספת Celery + Redis לאוטומציות (התראות, חישובי תמחיר מתוזמנים, סגירת מלאי).
- CI/CD (GitHub Actions) + פריסה על שרת/קונטיינרים מנוהלים.
- חיבור Frontend (React/Next.js) עם RTL ותמיכה מלאה בעברית.

## רישוי
שימוש חופשי לפרויקט שלך. אין אחריות. 
